@javax.xml.bind.annotation.XmlSchema(namespace = "http://se457.depaul.edu/")
package edu.depaul.se457;
